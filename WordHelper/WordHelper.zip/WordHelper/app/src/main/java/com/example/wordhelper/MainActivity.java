package com.example.wordhelper;

import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.view.View;
import android.widget.Toast;

import com.example.wordhelper.base.BaseFragmentActivity;

public class MainActivity extends BaseFragmentActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initView();
    }

    @Override
    public void initView() {

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.act_1_layout:
                showToast("Recommend");
                break;
            case R.id.act_2_layout:
                showToast("Search");
                break;
            case R.id.act_3_layout:
                showToast("My plan");
                break;
        }
    }
}
