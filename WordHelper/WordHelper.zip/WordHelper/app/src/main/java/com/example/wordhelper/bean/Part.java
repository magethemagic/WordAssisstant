package com.example.wordhelper.bean;

import org.greenrobot.greendao.annotation.Entity;
import org.greenrobot.greendao.annotation.Generated;
import org.greenrobot.greendao.annotation.Id;
import org.greenrobot.greendao.annotation.Index;
import org.greenrobot.greendao.annotation.NotNull;
import org.greenrobot.greendao.annotation.Property;
import org.greenrobot.greendao.annotation.Transient;

@Entity(
        nameInDb = "userName",
        indexes = {
                @Index(value = "name")
        }
)
public class Part {
@Id(autoincrement = true)
    private Long id;
@Property(nameInDb = "name")
@NotNull
private String name;

private String userAddr;
@Transient
    private String userTempSign;
@Generated(hash = 910920551)
public Part(Long id, @NotNull String name, String userAddr) {
    this.id = id;
    this.name = name;
    this.userAddr = userAddr;
}
@Generated(hash = 130301790)
public Part() {
}
public Long getId() {
    return this.id;
}
public void setId(Long id) {
    this.id = id;
}
public String getName() {
    return this.name;
}
public void setName(String name) {
    this.name = name;
}
public String getUserAddr() {
    return this.userAddr;
}
public void setUserAddr(String userAddr) {
    this.userAddr = userAddr;
}
}
