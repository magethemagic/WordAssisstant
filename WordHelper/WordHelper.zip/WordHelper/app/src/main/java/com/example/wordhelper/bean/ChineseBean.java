package com.example.wordhelper.bean;

import java.util.ArrayList;

public class ChineseBean {
private ArrayList<Symbol>symbols;


public class Symbol{
    private ArrayList<Parts> parts;

    private class Parts{
        private ArrayList<Means>means;

        private class Means{

        }
    }
}

}
