package com.example.wordhelper.base;

import android.app.Activity;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public abstract class BaseFragmentActivity extends FragmentActivity {
    public TextView findTextViewById(int id){
            return (TextView) findViewById(id);
    }
    public ImageView findImageViewById(int s){
        return (ImageView) findViewById(s);
    }
    public LinearLayout findLinById(int id){
        return (LinearLayout) findViewById(id);
    }
    public EditText findEdtById(int id){
        return (EditText) findViewById(id);
    }
    public Button findButById(int id){
        return (Button) findViewById(id);
    }
    public void showToast(String string){
        Toast.makeText(this,string,Toast.LENGTH_SHORT).show();
    }
    public abstract void initView();


}
